import tkinter as tk
import random
import string

def generate_password():
    length = 12
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for _ in range(length))
    password_var.set(password)

def toggle_theme():
    global dark_mode
    dark_mode = not dark_mode

    if dark_mode:
        root.configure(bg="#00008B")  # Тёмно-синий фон
        entry.configure(bg="#1a1a2e", fg="white", insertbackground="white")
        generate_button.configure(bg="#2f2f75", fg="white")
        theme_button.configure(bg="#2f2f75", fg="white", text="Светлая тема")
    else:
        root.configure(bg="#7a59ba")
        entry.configure(bg="white", fg="black", insertbackground="black")
        generate_button.configure(bg="white", fg="black")
        theme_button.configure(bg="white", fg="black", text="Тёмная тема")

root = tk.Tk()
root.title("Генератор паролей")
root.geometry("300x170")
root.configure(bg="#7a59ba")
root.iconbitmap("icon.ico")

password_var = tk.StringVar()
dark_mode = False  # Начинаем со светлой темы

entry = tk.Entry(root, textvariable=password_var, font=("Arial", 14), justify="center", bg="white")
entry.pack(pady=10)

generate_button = tk.Button(root, text="Сгенерировать пароль", command=generate_password, font=("Arial", 12), bg="white")
generate_button.pack(pady=5)

theme_button = tk.Button(root, text="Тёмная тема", command=toggle_theme, font=("Arial", 10), bg="white")
theme_button.pack(pady=5)

root.mainloop()

